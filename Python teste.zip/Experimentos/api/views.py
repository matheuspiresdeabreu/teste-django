from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from rest_framework.parsers import JSONParser
from .models import Produto
from .serializer import ProdutoSerializer 
# Create your views here.
from django.views.decorators.csrf import csrf_exempt


@csrf_exempt
def listaProduto(request):
    
    if request.method == 'GET':
        produtos = Produto.objects.all()
        serializer = ProdutoSerializer(produtos,many=True)
        return JsonResponse(serializer.data,safe=False)

    elif request.method == 'POST':
        req = JSONParser().parse(request)
        serializer = ProdutoSerializer(data=req)

        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data, status=201)
        return JsonResponse(serializer.errors, status=400)

@csrf_exempt
def detalheProduto(request,pk):
    try:
        produto = Produto.objects.get(pk=pk)
    except Produto.DoesNotExist:
        return HttpResponse(status=404)

    if request.method == 'GET':
        serializer = ProdutoSerializer(produto)
        return JsonResponse(serializer.data, status=200)

    elif request.method == 'PUT':
        data = JSONParser().parse(request)
        serializer = ProdutoSerializer(produto, data=data)
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data,status=201)
        return JsonResponse(serializer.errors,status=400)
    elif request.method == 'DELETE':
        produto.delete()
        return HttpResponse(status=204)


@csrf_exempt
def filtroValor(request,campo,cFiltro,vl):
    if request.method == 'GET':
        
        if campo == "valor_venda":
            selecProdutos = []
            produtos = Produto.objects.all()
            
            
            if cFiltro == "min":
                for prod in produtos:
                    if prod.valor_venda > vl:
                        selecProdutos.append(prod)
            elif cFiltro == "max":
                for prod in produtos:
                    if prod.valor_venda < vl:
                        selecProdutos.append(prod)
                    
            if len(selecProdutos) != 0:    
                serializer = ProdutoSerializer(selecProdutos,many=True)
                return JsonResponse(serializer.data,safe=False)
            else:
                serializer = ProdutoSerializer(selecProdutos,many=True)
                return JsonResponse(serializer.data, status=404)

        elif campo == "custo":
            selecProdutos = []
            produtos = Produto.objects.all()
            
            
            if cFiltro == "min":
                for prod in produtos:
                    if prod.custo > vl:
                        selecProdutos.append(prod)
            elif cFiltro == "max":
                for prod in produtos:
                    if prod.custo < vl:
                        selecProdutos.append(prod)
                    
            if len(selecProdutos) != 0:    
                serializer = ProdutoSerializer(selecProdutos,many=True)
                return JsonResponse(serializer.data,safe=False)
            else:
                serializer = ProdutoSerializer(selecProdutos,many=True)
                return JsonResponse(serializer.data, status=404)
    
@csrf_exempt
def busca(request,search):
    if request.method == 'GET':
        selecProdutos = []
        produtos = Produto.objects.all()
    
        for prod in produtos:
            if prod.descricao == search or prod.categoria == search or prod.sub_categoria == search or \
                prod.marca == search or prod.modelo == search or prod.fabricante == search:
                    selecProdutos.append(prod)
                
        if len(selecProdutos) != 0:    
            serializer = ProdutoSerializer(selecProdutos,many=True)
            return JsonResponse(serializer.data,safe=False)
        else:
            serializer = ProdutoSerializer(selecProdutos,many=True)
            return JsonResponse(serializer.data, status=404)

def buscaCampo(request,campo,search):
    if request.method == 'GET':
        selecProdutos = []
        produtos = Produto.objects.all()
    
        if campo == "descricao":
            for prod in produtos:
                if prod.descricao == search: 
                    selecProdutos.append(prod)


        if campo == "categoria":
            for prod in produtos:
                if prod.categoria == search: 
                    selecProdutos.append(prod)
        if campo == "sub_categoria":
            for prod in produtos:
                if prod.sub_categoria == search: 
                    selecProdutos.append(prod)

        if campo == "marca":
            for prod in produtos:
                if prod.marca == search: 
                    selecProdutos.append(prod)
        if campo == "modelo":
            for prod in produtos:
                if prod.modelo == search: 
                    selecProdutos.append(prod)
        if campo == "fabricante":
            for prod in produtos:
                if prod.fabricante == search: 
                    selecProdutos.append(prod)

        if len(selecProdutos) != 0:    
            serializer = ProdutoSerializer(selecProdutos,many=True)
            return JsonResponse(serializer.data,safe=False)
        else:
            serializer = ProdutoSerializer(selecProdutos,many=True)
            return JsonResponse(serializer.data, status=404)