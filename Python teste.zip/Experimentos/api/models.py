from django.db import models

# Create your models here.
class Produto(models.Model):
    id = models.IntegerField(primary_key=True)
    descricao = models.CharField(max_length=258)
    sku = models.CharField(max_length=64)
    custo = models.FloatField()
    valor_venda = models.FloatField()
    categoria = models.CharField(max_length=258)
    sub_categoria = models.CharField(max_length=258)
    marca = models.CharField(max_length=258)
    modelo = models.CharField(max_length=258)
    fabricante = models.CharField(max_length=258)
