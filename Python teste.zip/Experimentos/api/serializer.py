from rest_framework import serializers
from .models import Produto 

class ProdutoSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    descricao = serializers.CharField(max_length=258)
    sku = serializers.CharField(max_length=64)
    custo = serializers.FloatField()
    valor_venda = serializers.FloatField()
    categoria = serializers.CharField(max_length=258)
    sub_categoria = serializers.CharField(max_length=258)
    marca = serializers.CharField(max_length=258)
    modelo = serializers.CharField(max_length=258)
    fabricante = serializers.CharField(max_length=258)

    def create(self,valid_data):
        return Produto.objects.create(**valid_data)

    def update(self, instance, valid_data):
        instance.id = valid_data.get('id',instance.id)
        instance.descricao = valid_data.get('descricao',instance.descricao)
        instance.sku = valid_data.get('sku',instance.sku)
        instance.custo = valid_data.get('custo',instance.custo)
        instance.valor_venda = valid_data.get('valor_venda',instance.valor_venda)
        instance.categoria = valid_data.get('categoria',instance.categoria)
        instance.sub_categoria = valid_data.get('sub_categoria',instance.sub_categoria)
        instance.marca = valid_data.get('marca',instance.marca)
        instance.modelo = valid_data.get('modelo',instance.modelo)
        instance.fabricante = valid_data.get('fabricante',instance.fabricante)
        instance.save()
        return instance